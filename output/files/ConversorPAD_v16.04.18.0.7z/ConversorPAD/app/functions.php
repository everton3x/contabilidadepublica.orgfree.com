<?php
declare(strict_types=1);

/**
 * Limpa o diretorio OUTPUT
 * @return void
 */
function clear_output(){
	$output = new DirectoryIterator("glob://output/*.*");
	
	trigger_error('Limpando OUTPUT');
	foreach($output as $file){
		if(unlink($file->getPathname()) === true){
			trigger_error("Exclusao de {$file->getPathname()} feita com sucesso!");
		}else{
			trigger_error("Erro na exclusao de {$file->getPathname()}", E_USER_WARNING);
		}
	}

	trigger_error('Limpeza de OUTPUT conclu�da');

}

/**
 * Carrega o layout
 * @param string $index ex.: BAL_DESP
 * @return array Retorna um array multidimensional com o layout
 */
function load_layout(string $index) : array {
	$file_name = "layout/".strtolower($index).".csv";
	if(!file_exists($file_name)){
		trigger_error("Arquivo de layout $file_name n�o encontrado", E_USER_ERROR);
		return [];
	}
	
	$file = file($file_name, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	
	$arr = [];
	
	$count = 0;
	foreach($file as $line){
		$csv = str_getcsv($line, ';');
		if($csv[0] !== strtoupper('ID')){
			$arr[$count]['id'] = $csv[0];
			$arr[$count]['type'] = $csv[1];
			$arr[$count]['len'] = $csv[2];
			$arr[$count]['start'] = $csv[3];
			$arr[$count]['transform'] = $csv[4];
			$count++;
		}
	}
	
	return $arr;
}

/**
 * Carregas as linhas do arquivo de dados
 * @param DirectoryInterator $file
 * @return array
 */
function load_input(DirectoryIterator $file) : array {
	$data = file($file->getPathname(), FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	if($data === false){
		trigger_error("Arquivo de dados {$file->getPathname()} n�o carregado", E_USER_ERROR);
		return [];
	}
	
	return $data;
}

/**
 * L� os dados e faz a convers�o
 * @param array $data {@see load_input()}
 * @param array $layout {@see load_layout()}
 * @param string $index
 * @return array
 */
function parse_data(array $data, array $layout, string $index) : array {
	$converted = [];
	$line_counter = 1;
	foreach($data as $line){
		if($line_counter === 1){
			trigger_error("Pulando primeira linha de $index");
			$line_counter++;
			continue;
		}elseif(strtoupper(substr($line, 0, 11)) === 'FINALIZADOR'){
			trigger_error("Encontrado finalizador de $index");
			return $converted;
		}
		foreach($layout as $field){
			$id = $field['id'];
			$type = $field['type'];
			$start = intval($field['start'] - 1);
			$len = intval($field['len']);
			$transform = $field['transform'];
			
			$converted[$line_counter][$id] = substr($line, $start, $len);
			
			if($type === 'texto' && strlen($transform) === 0){
				$transform = 'aspas';
			}elseif($type === 'data' && strlen($transform) === 0){
				$transform = 'data';
			}elseif($type === 'moeda' && strlen($transform) === 0){
				$transform = 'moeda';
			}elseif($type === 'inteiro' && strlen($transform) === 0){
				$transform = 'inteiro';
			}else{
				$transform = $field['transform'];
			}
			
			if(strlen($transform) > 0 ){
				$converted[$line_counter][$id] = $transform($converted[$line_counter][$id]);
			}
		}
		$line_counter++;
	}
	
	return $converted;
}

/**
 * Monta a linha com o cabe�alho do arquivo CSV
 * @param array $layout {@see load_layout()}
 * @return string
 */
function build_header(array $layout) : string {
	$header = [];
	foreach($layout as $row){
		$header[] = '"'.$row['id'].'"';
	}
	$str = implode(';', $header).PHP_EOL;
	//echo $str;
	return $str;
}

/**
 * Converte os dados de uma linha de array para string CSV
 * @param array $line
 * @return string
 */
function build_csv(array $line) : string {
	$str = implode(';', $line).PHP_EOL;
	//echo $str;
	return $str;
}

/**
 * Converte o arquivo de dados do PAD
 * @param DirectoryInterator $input_file
 * @return void
 */
function convert_file(DirectoryIterator $input_file){
	
	$index = basename(strtoupper($input_file->getFilename()), '.TXT');//ex.: BAL_DESP
	trigger_error("Convertendo $index");
	
	//layout
	trigger_error("Carregando layout para $index");
	$layout = load_layout($index);
	
	if(count($layout) === 0){
		trigger_error("$index nao sera convertido", E_USER_WARNING);
		return;
	}
	
	//arquivo de dados
	trigger_error("Carregando dados de $index");
	$input = load_input($input_file);
	
	if(count($input) === 0){
		trigger_error("$index nao sera convertido", E_USER_WARNING);
		return;
	}
	
	//converte as linhas
	trigger_error("Convertendo dados de $index");
	$lines_converted = parse_data($input, $layout, $index);
	trigger_error("Convertidas ".count($lines_converted)." de $index");
	//print_r($lines_converted);
	
	//salvando os dados
	if(count($lines_converted) === 0){
		trigger_error("Nao ha dados para salvar de $index", E_USER_WARNING);
		return;
	}
	
	/*trigger_error("Criando arquivo de saida para $index");
	if($output = fopen("output/$index.csv", 'wb') === false){
		trigger_error("Nao foi possivel criar arquivo de saida para $index", E_USER_ERROR);
		return;
	}
	
	trigger_error("Salvando saida para $index");
	
	fwrite($output, build_header($layout));
	
	$line_counter = 0;
	foreach($lines_converted as $line){
		$str = build_csv($line);
		if(fwrite($output, $str) === false){
			//trigger_error("$str", E_USER_WARNING);
			echo "Porra de erro\n\r";
		}else{
			$line_counter++;
		}
	}
	
	trigger_error("Salvos $line_counter registros de $index");
	
	fclose($output);
	trigger_error("Arquivo de saida para $index fechado");*/
	
	trigger_error("Preparando dados de saida para $index");
	
	$output_str = build_header($layout);//cabe�alhos
	
	$line_counter = 0;
	foreach($lines_converted as $line){
		$output_str .= build_csv($line);
		$line_counter++;
	}
	
	if(file_put_contents("output/$index.csv", $output_str, FILE_TEXT) === false){
		trigger_error("Nao foi possivel criar arquivo de saida para $index", E_USER_ERROR);
		return;
	}else{
		trigger_error("Salvos $line_counter registros de $index");
	}
	
	trigger_error("Conversao de $index terminada");
	
	
	
}

trigger_error('Funcoes carregadas');
