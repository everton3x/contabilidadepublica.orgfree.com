<?php
declare(strict_types=1);
trigger_error('Carregando as configuracoes');

$config = parse_ini_file('config.ini');

foreach($config as $k => $v){
	trigger_error("$k = $v");
}

trigger_error('Configuracoes carregadas');
