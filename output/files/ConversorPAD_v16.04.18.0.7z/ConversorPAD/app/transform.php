<?php
declare(strict_types=1);
/**
 * Poem o conteúdo de $data entre aspas para formato de texto do CSV
 * @param string $data
 * @return string
 */
function aspas(string $data) : string {
	return '"'.$data.'"';
}

/**
 * Formata $data para o formato de data dd/mm/yyyy
 * @param string $data
 * @return string
 */
function data(string $data) : string {
	$dia = substr($data, 0, 2);
	$mes = substr($data, 2, 2);
	$ano = substr($data, 4, 4);
	
	return "$dia/$mes/$ano";
}

/**
 * Formata $data para o formato de moeda. ex.: 10.000,00
 * @param string $data
 * @return string
 */
function moeda(string $data) : string {
	/*//echo "$data\n\r";
	
	$centavos = (int) substr($data, strlen($data) - 2, 2);
	//echo "$centavos\n\r";
	
	$reais = (int) substr($data, 0, strlen($data) - 2);
	//echo "$reais\n\r";
	
	$moeda = (float) "$reais.$centavos";
	//echo "$moeda\n\r";
	
	$valor = number_format($moeda, 2, ',', '.');
	//echo "$valor\n\r";
	
	return $valor;*/
	
	return number_format($data / 100, 2, ',', '.');
}

/**
 * Converte $data para inteiro
 * @param string $data
 * @return integer
 */
function inteiro(string $data) : int {
	return intval($data);
}

/**
 * Formata de acordo com a máscara de natureza de despesa orçamentária do TCE/RS. Ex.:	4.5.9.0.66.99.00.00.00
 * @param string $data
 * @return string
 */
function ndo_tce(string $data) : string {
	$ndo = '';
	$start = 0;
	for($i = 0; $i < strlen($data); $i++){
		if($data[$i] !== '0'){
			$start = $i;
			break;
		}
	}
	
	$data = substr($data, $start);
	
	$ndo = str_pad($data, 14, "0", STR_PAD_RIGHT);
	$ndo_tce = "{$ndo[0]}.{$ndo[1]}.{$ndo[2]}.{$ndo[3]}.{$ndo[4]}{$ndo[5]}.{$ndo[6]}{$ndo[7]}.{$ndo[8]}{$ndo[9]}.{$ndo[10]}{$ndo[11]}.{$ndo[12]}{$ndo[13]}";
	return $ndo_tce;
}

/**
 * Formata de acordo com a máscara de natureza de receita orçamentária do TCE/RS. Ex.:	1.1.1.2.04.00.00.00.00
 * @param string $data
 * @return string
 */
function nro_tce(string $data) : string {
	$ndo = '';
	$start = 0;
	for($i = 0; $i < strlen($data); $i++){
		if($data[$i] !== '0'){
			$start = $i;
			break;
		}
	}
	
	$data = substr($data, $start);
	
	$ndo = str_pad($data, 14, "0", STR_PAD_RIGHT);
	$ndo_tce = "{$ndo[0]}.{$ndo[1]}.{$ndo[2]}.{$ndo[3]}.{$ndo[4]}{$ndo[5]}.{$ndo[6]}{$ndo[7]}.{$ndo[8]}{$ndo[9]}.{$ndo[10]}{$ndo[11]}.{$ndo[12]}{$ndo[13]}";
	return $ndo_tce;
}

/**
 * Formata de acordo com a máscara de código de conta contábil do TCE/RS. Ex.:	2.1.8.8.1.01.12.00.00.00
 * @param string $data
 * @return string
 */
function cc_tce(string $data) : string {
	$ndo = '';
	$start = 0;
	for($i = 0; $i < strlen($data); $i++){
		if($data[$i] !== '0'){
			$start = $i;
			break;
		}
	}
	
	$data = substr($data, $start);
	
	$ndo = str_pad($data, 15, "0", STR_PAD_RIGHT);
	$ndo_tce = "{$ndo[0]}.{$ndo[1]}.{$ndo[2]}.{$ndo[3]}.{$ndo[4]}.{$ndo[5]}{$ndo[6]}.{$ndo[7]}{$ndo[8]}.{$ndo[9]}{$ndo[10]}.{$ndo[11]}{$ndo[12]}.{$ndo[13]}{$ndo[14]}";
	return $ndo_tce;
}

/**
 * Retorna o ano do empenho
 * @param string $data
 * @return integer
 */
function ano_empenho(string $data) : int {
	$ndo = '';
	$start = 0;
	for($i = 0; $i < strlen($data); $i++){
		if($data[$i] !== '0'){
			$start = $i;
			break;
		}
	}
	
	$data = substr($data, $start);
	
	$ano = substr($data, 0, 4);

	return (int) $ano;
}

/**
 * Retorna o número do empenho
 * @param string $data
 * @return integer
 */
function numero_empenho(string $data) : int {
	$ndo = '';
	$start = 0;
	for($i = 0; $i < strlen($data); $i++){
		if($data[$i] !== '0'){
			$start = $i;
			break;
		}
	}
	
	$data = substr($data, $start);
	
	return (int) substr($data, 4);
}

/**
 * Retira zeros iniciais
 * @param string $data
 * @return string
 */
function retira_zeros(string $data) : string {
	$strlen = strlen($data);
	$ndo = '';
	$start = 0;
	for($i = 0; $i < strlen($data); $i++){
		if($data[$i] !== '0'){
			$start = $i;
			break;
		}
	}
	
	$data = substr($data, $start);
	
		return $ndo = str_pad($data, $strlen, "0", STR_PAD_RIGHT);
}

/**
 * Prepara o valor quando $data é 123456+ ou 123456-
 * @param string $data
 * @return string
 */
function valor(string $data) : string {
	//echo "$data\n\r";
	$tamanho = strlen($data);
	$ultimo = $data[$tamanho - 1];
	//echo "$ultimo\n\r";
	$moeda = substr($data, 0, $tamanho - 1);
	//echo "$moeda\n\r";
	$valor = moeda($moeda);
	//echo "$valor\n\r";
	
	return "$ultimo$valor";
}
