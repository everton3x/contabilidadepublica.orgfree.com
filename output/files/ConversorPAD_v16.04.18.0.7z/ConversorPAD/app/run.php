<?php
declare(strict_types=1);
//configura manuseamento de erros
error_reporting(E_ALL|E_STRICT);

function error_handler($errno, $errmsg, $filename, $linenum){
	
	$error_type = array (
		E_ERROR => 'Error',
		E_WARNING => 'Warning',
		E_PARSE => 'Parsing Error',
		E_NOTICE => 'Notice',
		E_CORE_ERROR => 'Core Error',
		E_CORE_WARNING => 'Core Warning',
		E_COMPILE_ERROR => 'Compile Error',
		E_COMPILE_WARNING => 'Compile Warning',
		E_USER_ERROR => 'User Error',
		E_USER_WARNING => 'User Warning',
		E_USER_NOTICE => 'User Notice',
		E_STRICT => 'Runtime Notice',
		E_RECOVERABLE_ERROR => 'Catchable Fatal Error'
	);
	
	if(!key_exists($errno, $error_type)){
		$e_type = 'Unexpected Error';
	}else{
		$e_type = $error_type[$errno];
	}
	
	$err = sprintf("%s\t%s\t%s in %s:%u".PHP_EOL, date('Y-m-d H:i:s'), $e_type, $errmsg, $filename, $linenum);
	
	error_log($err, 3, 'conversorpad.log');
	
	/*switch($errno){
		case E_USER_ERROR:
		case E_USER_WARNING:
		case E_USER_NOTICE:
			echo $errmsg.PHP_EOL;
			break;
		default:
			break;
	}*/
	echo $errmsg.PHP_EOL;
};

function exception_handler($e){
	error_handler($e->getCode(), $e->getMessage(), $e->getFile(), $e->getLine());
}

set_error_handler('error_handler');
set_exception_handler('exception_handler');

trigger_error('Iniciando o sistema');

//rotinas de inicializacao
require 'functions.php';
require 'config.php';
require 'transform.php';
clear_output();

//iniciando a conversao

trigger_error('Iniciando a conversao em '.date('d-m-Y H:i:s'));

$input_dir = new DirectoryIterator("glob://input/*.*");

foreach($input_dir as $input_file){
	convert_file($input_file);
}

trigger_error('Conversao terminada em '.date('d-m-Y H:i:s'));
