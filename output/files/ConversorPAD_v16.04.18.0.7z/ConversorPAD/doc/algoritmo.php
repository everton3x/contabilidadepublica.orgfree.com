<?php
loop em input/
	para cada arquivo em input/, verifica se existe layout csv em layout/
		se existe
			l� o layout csv
			l� os dados do arquivo txt
			loop nas linhas do txt at� que seja encontrado no in�cio da linha a sequ�ncia "FINALIZADOR"
				se � a primeira linha do txt
					n�o faz nada
				se n�o
					loop no layout
						executa a fun��o substr do PHP com os dados de cada linha do layout csv
						se tem transform definido ou padr�o
							executa o transform
						fim do se
						salva o retorno em vari�vel tempor�ria
					fim do loop no layout
			fim do loop nas linhas do txt
			se tem linhas convertidas
				salva em output/
			se n�o
				warning
			fim do se
		se n�o
			warning
		fim do se
fim do loop em input/
